public class Player extends Unit{
	
	//curArmor
	//curWeapon
	//curRings
	private int gold;
	private int maxHP;	//don't need this
	private int exp;
	//Hunger
	//private Inventory inventory;
	
	
	public Player() {
		this.name="@";
	}

	//public int fight(int[] dir, char monster, Weapon weapon, boolean thrown) {
		// TODO
	//}
	
	public void checkLevelUp() {
		// TODO
	}
	
	public void checkHunger() {
		// TODO
	}
}
