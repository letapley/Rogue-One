public class Unit {

	int statusTime;
	int level;
	int strength;
	int hp;
	int maxHP;
	int armor;
	String name;
	
	public Unit() {
		// TODO constructor and stuff
	}
	
	public String toString(){
		return name;
	}
	
	public void move(int[] dir) {
		// TODO figure out this direction thing
		//Call level.move(Player, Direction)?
	}
	
	public boolean isDead() {
		// TODO write the code and maybe add in an attribute
		
		return false;
	}
}