
public class Enemy extends Unit{

	//special ability
	//boolean[] flags
	private int armorClass;
	private double treasureChance;
	private int expGained;
	private int dmg;
	
	public Enemy() {
		this.name="E";
		// TODO Auto-generated constructor stub
	}
	
	public void chase() {
		
	}
	
	public void moveTo() {
		
	}
	
	public void moveRandom() {
		
	}
	
	public int attackPlayer() {
		return 0;
		
	}
	
	public void removeMonster() {
		
	}
	
	public void dropTreasure() {
		
	}

}
